package egovframework.saa.module.student.service.impl;

import java.sql.SQLException;
import java.util.List;

import org.egovframe.rte.psl.dataaccess.mapper.Mapper;
import org.egovframe.rte.psl.dataaccess.util.EgovMap;

@Mapper("studentMapper")
public interface StudentMapper {

	List<EgovMap> selectStudentList(EgovMap paramMap) throws SQLException;

	EgovMap selectStudentInfoList(String id) throws SQLException;

	void insertStudent(EgovMap student) throws SQLException;



}
