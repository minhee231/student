package egovframework.saa.module.student.service;

import java.sql.SQLException;
import java.util.List;

import org.egovframe.rte.psl.dataaccess.util.EgovMap;

public interface StudentService {

	List<EgovMap> selectStudentList(EgovMap paramMap) throws SQLException;

	EgovMap selectStudentInfoList(String id) throws SQLException;

	void insertStudent(EgovMap student) throws SQLException;

}
