package egovframework.saa.module.student.service.impl;

import java.sql.SQLException;
import java.util.List;
import java.util.NoSuchElementException;

import javax.annotation.Resource;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.egovframe.rte.psl.dataaccess.util.EgovMap;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import egovframework.saa.module.student.service.StudentService;

@Service("studentService")
public class StudentServiceImpl extends EgovAbstractServiceImpl implements StudentService {

	@Resource(name = "studentMapper")
	private StudentMapper studentMapper;

	public List<EgovMap> selectStudentList(EgovMap paramMap) throws DataAccessException, SQLException {
		return studentMapper.selectStudentList(paramMap);
	}

	public EgovMap selectStudentInfoList(String id) throws DataAccessException, SQLException {
		return studentMapper.selectStudentInfoList(id);
	}

	public void insertStudent(EgovMap student) throws SQLException {
        studentMapper.insertStudent(student);
    }







}
