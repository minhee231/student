package egovframework.saa.mngr.student.web;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.egovframe.rte.psl.dataaccess.util.EgovMap;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import egovframework.saa.module.student.service.StudentService;

@Controller
public class StudentController {

	/** studentService */
	@Resource(name = "studentService")
	private StudentService studentService;

	private static final Logger LOGGER = LogManager.getLogger(StudentController.class);

	@RequestMapping(value = "/student/student_list.do")
	public String selectStudentList(ModelMap model, HttpServletRequest request) throws DataAccessException, RuntimeException, IOException, SQLException {
		LOGGER.info("학생 목록");

		String firstIndex = request.getParameter("firstIndex") == null ? "0" : request.getParameter("firstIndex");

		String lastIndex = request.getParameter("lastIndex") == null ? "10" : request.getParameter("lastIndex");

		EgovMap egovMap = new EgovMap();
		egovMap.put("firstIndex", Integer.parseInt(firstIndex));
		egovMap.put("lastIndex", Integer.parseInt(lastIndex));
		LOGGER.info("egovMap ::: " + egovMap);

		List<EgovMap> studentList = studentService.selectStudentList(egovMap);
		model.addAttribute("studentList", studentList);

		return "saa/student/student_list";
	}

	@RequestMapping(value = "/student/student_view.do")
	public String selectStudentInfo(ModelMap model, HttpServletRequest request) throws DataAccessException, RuntimeException, IOException, SQLException {
		LOGGER.info("학생 뷰");

		String studentId = request.getParameter("student_id");

		LOGGER.info(studentId);
		EgovMap studentInfo = studentService.selectStudentInfoList(studentId);
		model.addAttribute("studentInfo", studentInfo);

		LOGGER.info(studentInfo);

		return "saa/student/student_view";

	}

	@RequestMapping(value = "/student/student_input.do")
	public String inputStudent(ModelMap model, HttpServletRequest request) throws DataAccessException, RuntimeException, IOException, SQLException {
		LOGGER.info("학생 등록");

		EgovMap egovMap = new EgovMap();
		LOGGER.info("egovMap ::: " + egovMap);

		return "saa/student/student_input";
	}

	@RequestMapping(value = "/student/student_input_proc.do")
	public String inputStudentProc(ModelMap model, HttpServletRequest request) throws DataAccessException, RuntimeException, IOException, SQLException {
		LOGGER.info("학생 등록 처리");

		String studentId = request.getParameter("student_id");
		String studentName = request.getParameter("student_name");
		String state = request.getParameter("state");
		String entrance = request.getParameter("entrance");
		String graduation = request.getParameter("graduation");
		String leaveYear = request.getParameter("leave_year");
		String expelledYear = request.getParameter("expelled_year");
		String studentSex = request.getParameter("student_sex");
		String studentDepartment = request.getParameter("student_department");
		String studentGrade = request.getParameter("student_grade");
		String studentClass = request.getParameter("student_class");
		String studentNumber = request.getParameter("student_number");

		EgovMap egovMap = new EgovMap();
		egovMap.put("studentId", studentId);
	    egovMap.put("studentName", studentName);
	    egovMap.put("state", state);
	    egovMap.put("entrance", entrance);
	    egovMap.put("graduation", graduation);
	    egovMap.put("leaveYear", leaveYear);
	    egovMap.put("expelledYear", expelledYear);
	    egovMap.put("studentSex", studentSex);
	    egovMap.put("studentDepartment", studentDepartment);
	    egovMap.put("studentGrade", studentGrade);
	    egovMap.put("studentClass", studentClass);
	    egovMap.put("studentNumber", studentNumber);

	    LOGGER.info("egovMap ::: " + egovMap);

	    studentService.insertStudent(egovMap);


		return "redirect:./student_list.do";
	}

	@RequestMapping(value = "/student/student_edit.do")
	public String editStudent(ModelMap model, HttpServletRequest request) throws DataAccessException, RuntimeException, IOException, SQLException {
		LOGGER.info("학생 수정");

		String studentId = request.getParameter("student_id");

		LOGGER.info(studentId);
		EgovMap studentInfo = studentService.selectStudentInfoList(studentId);
		model.addAttribute("studentInfo", studentInfo);

		LOGGER.info(studentInfo);

		return "saa/student/student_edit";
	}

	@RequestMapping(value = "/student/student_edit_proc.do")
	public String editStudentProc(ModelMap model, HttpServletRequest request) throws DataAccessException, RuntimeException, IOException, SQLException {
		LOGGER.info("학생 수정처리");

		String studentId = request.getParameter("student_id");
		String studentName = request.getParameter("student_name");
		String state = request.getParameter("state");
		String entrance = request.getParameter("entrance");
		String graduation = request.getParameter("graduation");
		String leaveYear = request.getParameter("leave_year");
		String expelledYear = request.getParameter("expelled_year");
		String studentSex = request.getParameter("student_sex");
		String studentDepartment = request.getParameter("student_department");
		String studentGrade = request.getParameter("student_grade");
		String studentClass = request.getParameter("student_class");
		String studentNumber = request.getParameter("student_number");

		EgovMap egovMap = new EgovMap();
		egovMap.put("studentId", studentId);
	    egovMap.put("studentName", studentName);
	    egovMap.put("state", state);
	    egovMap.put("entrance", entrance);
	    egovMap.put("graduation", graduation);
	    egovMap.put("leaveYear", leaveYear);
	    egovMap.put("expelledYear", expelledYear);
	    egovMap.put("studentSex", studentSex);
	    egovMap.put("studentDepartment", studentDepartment);
	    egovMap.put("studentGrade", studentGrade);
	    egovMap.put("studentClass", studentClass);
	    egovMap.put("studentNumber", studentNumber);

	    LOGGER.info("egovMap ::: " + egovMap);

	    studentService.insertStudent(egovMap);


		return "redirect:./student_list.do";
	}
}
